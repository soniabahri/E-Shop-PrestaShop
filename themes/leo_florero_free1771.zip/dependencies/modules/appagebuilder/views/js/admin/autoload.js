/*
 *  @Website: apollotheme.com - prestashop template provider
 *  @author Apollotheme <apollotheme@gmail.com>
 *  @copyright  2007-2019 Apollotheme
 *  @description: 
 */

$(document).ready(function() {
    if (typeof autoload_func_name !== 'undefined') {
        window[autoload_func_name]();
    }
});
