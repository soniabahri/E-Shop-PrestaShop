<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocklanguages}prestashop>blocklanguages_d5988791c07fedc0e2fc77683b4e61f6'] = 'Language block';
$_MODULE['<{blocklanguages}prestashop>blocklanguages_5bc2cbadb5e09b5ef9b9d1724072c4f9'] = 'Adds a block allowing customers to select a language for your store\'s content.';


return $_MODULE;
