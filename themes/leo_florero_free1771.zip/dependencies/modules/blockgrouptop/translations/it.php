<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_9827d3df66ae8d506d0abc46ebc860b0'] = 'Block Group Top';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_dc5ddf41afac839ace02f1d9c44531c9'] = 'Aggiunge un blocco che permette ai clienti di selezionare una lingua per il contenuto negozi.';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_f38f5974cdc23279ffe6d203641a8bdf'] = 'Impostazioni aggiornate.';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_27e86e8ba547905b1e374817add18330'] = 'Info Blocca utente';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_0105bbbc3f8d8fa1c91d26357e89d25b'] = 'Attiva / Disattiva Blocca utente Info.';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Abilitato';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabilitato';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_c9cc8cce247e49bae79f15173ce97354'] = 'Salvare';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_51ac4bf63a0c6a9cefa7ba69b4154ef1'] = 'Ambiente';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_4994a8ffeba4ac3140beb89e8d41f174'] = 'Lingua';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_386c339d37e737a436499d423a77df0c'] = 'Moneta';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_2cbfb6731610056e1d0aaacde07096c1'] = 'Visualizza il mio conto cliente';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_8b1a9953c4611296a827abf8c47804d7'] = 'Ciao';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_c87aacf5673fada1108c9f809d354311'] = 'Disconnessione';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_d4151a9a3959bdd43690735737034f27'] = 'Accedi al tuo conto cliente';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_b6d4223e60986fa4c9af77ee5f7149c5'] = 'Registrati';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Il mio account';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_6ff063fbc860a79759a7369ac32cee22'] = 'Check-out';
